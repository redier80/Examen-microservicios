package com.codigo.ms_empresas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsEmpresasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsEmpresasApplication.class, args);
	}

}
