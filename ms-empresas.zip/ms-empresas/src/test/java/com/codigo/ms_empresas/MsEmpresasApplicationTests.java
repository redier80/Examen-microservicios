package com.codigo.ms_empresas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsEmpresasApplicationTests {

	@Test
	void contextLoads() {
	}

}
